export const SlideShowData = [
    {
        image: '/images/Slide1.png'
    },
    {
        image: '/images/Slide2.png'
    },
    {
        image: '/images/Slide3.png'
    },
    {
        image: '/images/Slide4.png'
    },
    {
        image: '/images/Slide5.png'
    },
    {
        image: '/images/Slide6.png'
    },
    {
        image: '/images/Slide7.png'
    },
    {
        image: '/images/Slide8.png'
    },
    {
        image: '/images/Slide9.png'
    },
    {
        image: '/images/Slide10.png'
    },
    {
        image: '/images/Slide11.png'
    },
    {
        image: '/images/Slide12.png'
    },
    {
        image: '/images/Slide13.png'
    },
    {
        image: '/images/Slide14.png'
    },
    {
        image: '/images/Slide15.png'
    },
    {
        image: '/images/Slide16.png'
    },
    {
        image: '/images/Slide17.png'
    },
    {
        image: '/images/Slide18.png'
    },
    {
        image: '/images/Slide19.png'
    },
]
